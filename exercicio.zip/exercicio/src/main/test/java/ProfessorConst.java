public class ProfessorConst {

    public static String CHRIS = 
        "{ \"nomeDoProfessor\": \"Christopher\", \n " +
            "\"horarioDeAtendimento\": 15, \n " +
            "\"periodo\": \"integral\"}";

    public static String MARCELO =
        "{ \"nomeDoProfessor\": \"Marcelo\", \n " +
            "\"horarioDeAtendimento\": 19, \n " +
            "\"periodo\": \"noturno\"}";

    public static String ERRO = 
        "{ \"MensagemErro\": \"erro\", \n }";  
}
