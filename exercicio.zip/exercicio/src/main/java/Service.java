public interface Service {
    
    public String busca(int id); //Metodo principal (que busca o prof externamente - "servidor")

}
